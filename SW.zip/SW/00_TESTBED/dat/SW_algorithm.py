import random
import numpy as np

up_seq = []
do_seq = []

for i in range(64):     
    up_seq.append(random.randint(0,3))   
for i in range(48):
    do_seq.append(random.randint(0,3))  
    
up_seq[0:8] = [0, 1, 0, 0, 2, 3, 1, 1]
do_seq[0:9] = [1, 1, 0, 0, 1, 2, 3, 0, 2]    
weight = np.zeros((49, 65)) 

for i in range(1, 49):
    for j in range(1, 65):
        
        if up_seq[j-1] == do_seq[i-1]:
            a = weight[i-1][j-1] + 3
        else:
            a = weight[i-1][j-1] - 3
        b = weight[i-1][j] - 2
        c = weight[i][j-1] - 2
        weight[i][j] = max([a, b, c, 0])
        
max_weight = np.max(weight)
max_weight_ind = np.unravel_index(weight.argmax(), weight.shape)

with open('ref.dat', 'w') as file:
    for i in range(64): 
        file.write(str(up_seq[i]))
        file.write('\n')
        
with open('query.dat', 'w') as file:
    for i in range(48): 
        file.write(str(do_seq[i]))
        file.write('\n')

with open('golden.dat', 'w') as file:
    file.write(hex(int(max_weight))[2:])  
    file.write('\n')
    file.write(hex(int(max_weight_ind[0]))[2:])
    file.write('\n')
    file.write(hex(int(max_weight_ind[1]))[2:]) 
    file.write('\n')
        
        
        
        
        
        
        
        